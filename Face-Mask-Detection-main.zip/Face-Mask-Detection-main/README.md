# Face-Mask-Detection
Built a Neural Network, to classify “mask” and “without_mask” images. 2. Using opencv, predict on each image in a webcam video( whether it belongs to “mask” or “without_mask” image). Round a rectangle on the detected face, and also put a text above that rectangle, depicting whether it is a masked or a non-masked image
Download few images of people wearing mask and no mask and create a dataset.
